# Grp467
Website with React front end, Node back end, and MariaDB database

npm install dotenv;
npm install mariadb;
npm install express;
npm install cors;
npm install react;
npm install nodemon;

